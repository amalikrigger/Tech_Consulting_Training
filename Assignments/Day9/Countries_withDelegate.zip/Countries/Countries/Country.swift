//
//  Country.swift
//  Countries
//
//  Created by MAC on 05/09/23.
//

import Foundation

struct Country: Decodable {
    let name: String
    let capital: String
}
